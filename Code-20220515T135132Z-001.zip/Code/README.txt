- Đây là 3 file sử dụng 4 thuật toán phổ biến là RNN ,LSTM, GRU, Bi-LSTM.
+ File 'POS_Tagging (Manual embedding model).ipynb' sử dụng bộ world embedding tự tạo, và chuyển hết về format chứ thường.
+ File 'POS_tagging(FastText).ipynb' sử dụng Fasttext là mô hình embedding chữ thường và khá nhẹ.
+ File 'POStagging(Word2vec).ipynb' sử dụng bộ world2vec của VLP.
+ File 'POStagging(HMW).ipynb' sử dụng thuật toán Hidden Markov Model